package com.test.automation.test;

import org.junit.Test;

import com.test.automation.base.Base;
import com.test.automation.pages.LoginPage;

public class TestLogin extends TestBase {
	
	LoginPage login;
	
	@Test
	public void loginTest() {
		login = new LoginPage();
		
		Base.initialize();
		prerequisite();
		
		Base.setup();
		login.createNewUser(name, email, password, confirmPassword);
		
	}
	
}
