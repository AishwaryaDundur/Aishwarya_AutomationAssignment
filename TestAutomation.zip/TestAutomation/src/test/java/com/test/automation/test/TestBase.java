package com.test.automation.test;

import com.test.automation.base.Base;
import com.test.automation.base.RestCalls;

public class TestBase {
	
	public String name, email, password, confirmPassword ;
	
	/**
	 * Method to check User is already available or Not. If Available, Delete
	 * All Users
	 */
	public void prerequisite() {
		boolean userExists;
		
		name = Base.config.getProperty("user");
		email = Base.config.getProperty("email");
		password = Base.config.getProperty("password");
		confirmPassword = Base.config.getProperty("confirmPass");
		
		userExists = RestCalls.checkForUserStatus(name);
		
		if(userExists){
			RestCalls.deleteAllUsers();
		}

	}
	
	
	
	
	

}
