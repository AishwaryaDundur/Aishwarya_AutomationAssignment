package com.test.automation.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.test.automation.pages.LoginPage;

public class Base {

	public static SelUtils selUtils;
	public static WaitMethods waitMethods;
	public static LoginPage loginPge;

	public static WebDriver driver;
	public static WebDriverWait wait;
	public static Properties config;
	
	/**
	 * Method to Initialize the Browser
	 */
	public static void setup() {
		driver = new HtmlUnitDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://85.93.17.135:9000/user/new");
		driver.manage().window().maximize();
		wait = new WebDriverWait(driver, 50);

		selUtils = PageFactory.initElements(driver, SelUtils.class);
		waitMethods = PageFactory.initElements(driver, WaitMethods.class);
		loginPge = PageFactory.initElements(driver, LoginPage.class);
	}

	/**
	 * Initializing the Testdata from xml files
	 */
	public static void initialize() {
		config = new Properties();
		try {
			config.loadFromXML(new FileInputStream(CommonConstants.CONFIGFILE));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Get Driver
	 * 
	 * @return
	 */
	public static WebDriver getDriver() {
		return driver;
	}

	/**
	 * Set Driver
	 * 
	 * @param driver
	 */
	public static void setDriver(WebDriver driver) {
		Base.driver = driver;
	}
	
	/**
	 * Captures screenshot on failure
	 * 
	 * @param filename
	 */
	public void captureScreenShotOnFailure(String filename) {
		try {
			File source = ((TakesScreenshot) driver)
					.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(source, new File(CommonConstants.SCREENSHOTPATH
					+ filename + ".jpg"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


}
