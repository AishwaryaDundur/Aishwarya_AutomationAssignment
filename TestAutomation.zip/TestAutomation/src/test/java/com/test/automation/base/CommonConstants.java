package com.test.automation.base;

import java.io.File;

public class CommonConstants {
	
	public final static String USERDIR="user.dir";
	public final static String CONFIGFILE = "config.xml";
	public final static String SCREENSHOTPATH = System.getProperty(USERDIR)+ File.separator+"screenshots"+File.separator+"screenshots_";
	public final static int IMPLICITTIME=15;
	public final static int ONESEC = 1000;
	public final static int TWOSEC = 2000;
	public final static int THREESEC = 3000;
	public final static int FOURSEC = 4000;
	public final static int FIVESEC = 5000;
	public final static int SIXSEC = 6000;
	public final static int SEVENSEC = 7000;
	public final static int TIMEOUTSIXTYSEC = 60000;
	
}
