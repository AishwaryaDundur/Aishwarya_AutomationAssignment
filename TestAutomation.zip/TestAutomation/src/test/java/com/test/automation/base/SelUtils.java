package com.test.automation.base;

import org.openqa.selenium.WebElement;


public class SelUtils {

	public WebElement webElement;

	/**
	 * Method for clicking on any WebElement
	 * @param webelement
	 */
	public void clickOnWebElement(WebElement webelement){
		webelement.click();
	}
	
	/**
	 * Common Method for enter data in input boxes
	 * @param object
	 * @param value
	 */
	public void populateInputBox(WebElement ele, String value) {
		if (!(ele.getAttribute("value").isEmpty())) {
			ele.clear();
		}
		ele.sendKeys(value);
	}
	
}
