package com.test.automation.base;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class WaitMethods {

	public WebDriver driver;
	private WebDriverWait wait = Base.wait;
	
	/**
	 * Get Driver from TestBase Class
	 */
	public WaitMethods() {
		this.driver = Base.getDriver();
	}
	
	/**
	 * wait for N second
	 */
	public static void waitNSec(int waitTime) {
		try {
			switch (waitTime) {
			case 1:
				Thread.sleep(CommonConstants.ONESEC);
				break;
			case 2:
				Thread.sleep(CommonConstants.TWOSEC);
				break;
			case 3:
				Thread.sleep(CommonConstants.THREESEC);
				break;
			case 4:
				Thread.sleep(CommonConstants.FOURSEC);
				break;
			case 5:
				Thread.sleep(CommonConstants.FIVESEC);
				break;
			case 6:
				Thread.sleep(CommonConstants.SIXSEC);
				break;
			case 7:
				Thread.sleep(CommonConstants.SEVENSEC);
				break;
			default:
				Assert.fail("Please specify the wait time upto 7. Currently given is: "
						+ waitTime);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			Thread.currentThread().interrupt();
			Assert.fail(e.getMessage());
		}
	}
	
	/**
	 * waitMethods.waitForElementVisible
	 * 
	 * @param object
	 */
	public void waitForElementVisible(WebElement object) {
		wait = new WebDriverWait(driver, 5);
		for (int i = 0; i < 5; i++) {
			try {
				wait.until(ExpectedConditions.visibilityOf(object));
				break;
			} catch (Exception e) {
				waitNSec(1);
			}
		}
	}
	
}
