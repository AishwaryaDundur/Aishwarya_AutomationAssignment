package com.test.automation.pages;

import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.test.automation.base.Base;
import com.test.automation.base.RestCalls;

public class LoginPage extends Base {

	@FindBy(id = "name")
	public static WebElement name_Loc;

	@FindBy(id = "email")
	public static WebElement email_Loc;

	@FindBy(id = "password")
	public static WebElement password_Loc;

	@FindBy(id = "confirmationPassword")
	public static WebElement confirmPass_Loc;

	@FindBy(xpath = "//button[contains(@type,'submit')]")
	public static WebElement submit_Loc;

	@FindBy(xpath = "//a[contains(.,'All User')]")
	public static WebElement allUser_Loc;

	/**
	 * Method to Create a New User
	 * 
	 * @param name
	 * @param email
	 * @param password
	 * @param confirmPass
	 */
	public void createNewUser(String name, String email, String password,
			String confirmPass) {
		try {
			waitMethods.waitForElementVisible(name_Loc);
			selUtils.populateInputBox(name_Loc, name);

			selUtils.populateInputBox(email_Loc, email);
			selUtils.populateInputBox(password_Loc, password);
			selUtils.populateInputBox(confirmPass_Loc, confirmPass);

			selUtils.clickOnWebElement(submit_Loc);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyUserCreation(String username) {
		boolean userStatus = false;
		userStatus = RestCalls.checkForUserStatus(username);
		Assert.assertTrue("The Newly Created User: " + username + " is Created.", userStatus);
	}

}
