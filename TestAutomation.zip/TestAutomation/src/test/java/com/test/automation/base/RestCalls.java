package com.test.automation.base;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

public class RestCalls {

	static URL restUrl;

	/**
	 * Method to Check for Duplicate User
	 * 
	 * @param user
	 */
	public static boolean checkForUserStatus(String user) {

		String inline = null;
		boolean userFound = false;

		try {
			restUrl = new URL("http://85.93.17.135:9000/user/all/json");
			HttpURLConnection conn = (HttpURLConnection) restUrl
					.openConnection();

			conn.setRequestMethod("GET");
			conn.connect();

			int responseCode = conn.getResponseCode();
			if (responseCode != 200) {
				throw new RuntimeException("Http Reponse code is: "
						+ responseCode);
			}

			Scanner sc = new Scanner(restUrl.openStream());
			while (sc.hasNext()) {
				inline += sc.nextLine();
			}
			sc.close();

			String[] removeNull = inline.split("null");
			String propArray = removeNull[removeNull.length - 1];

			JSONArray jsArr = new JSONArray(propArray);
			for (int i = 0; i < jsArr.length(); i++) {
				JSONObject jsonobject = jsArr.getJSONObject(i);
				String name = jsonobject.getString("name");
				String email = jsonobject.getString("email");
				if (name.equalsIgnoreCase(user)) {
					userFound = true;
					System.out.println(name + " : " + email);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return userFound;
	}

	/**
	 * Method to Delete All the Users
	 */
	public static void deleteAllUsers() {
		try {
			restUrl = null;
			restUrl = new URL("http://85.93.17.135:9000/user/all");
			HttpURLConnection conn = (HttpURLConnection) restUrl.openConnection();

			conn.setRequestMethod("DELETE");
			conn.connect();

			int responseCode = conn.getResponseCode();
			if (responseCode != 200) {
				throw new RuntimeException("Http Reponse code is: "
						+ responseCode);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
